$(function(){
	
var slider = new MasterSlider();
    slider.setup('masterslider' , {
        width:366,
        height:366,
        space:10,
        loop:true,
        view:'prtialwave'
    });
     
    slider.control('arrows');  
    slider.control('slideinfo',{insertTo:"#partial-view-1" , autohide:false});
    slider.control('circletimer' , {color:"#FFFFFF" , stroke:9});



});
