(function($){
	$(function(){
		
		
		var xz=0;
			$("div.user > a").click(function(){
				if(xz==0){
					$(this).addClass('user_arrow');
					$("div.user_list").fadeIn(300);
					xz++;
				}else{
					$(this).removeClass('user_arrow');
					$("div.user_list").fadeOut(300);
					xz--;
				}
			return false;
		});
		
		
		var ab=0;
		$("a.campaign_btn").click(function(){
			if(ab==0){
				$(this).addClass("campaign_arrow");
				$("div.publish").fadeIn(300);
				ab++;
			}else{
				$(this).removeClass("campaign_arrow");
				$("div.publish").fadeOut(300);
				ab--;
			}
			return false;
		});
		
		
		var cd=0;
		$("a.down").click(function(){
			if(cd==0){
				$("div.date_time").slideToggle(300);
				$(this).addClass("down_arrow");
				cd++;
			}else{
				$("div.date_time").slideUp(300);
				$(this).removeClass("down_arrow");
				cd--;
			}
			return false;
		});
		
		
		var ele = $("div.left_panel > ul");
			var all_anchor = ele.children("li").children("a");
			$("div.left_panel > ul > li > ul").fadeOut(300);
			all_anchor.click(function(){
			
			if($(this).next('ul').length)
		   {
			if($(this).next().is(":hidden")){
			   $("div.left_panel > ul > li > ul").fadeOut();
			   all_anchor.removeClass("active");
			   $(this).addClass("active").next('ul').fadeIn();
			  }else{
			   $(this).removeClass("active").next('ul').fadeOut();
			  };
		   }
		   else
		   {
			$("div.left_panel > ul > li > ul").fadeOut();
			   all_anchor.removeClass("active");
			   $(this).addClass("active");
		   }
		   return false;
		});
		
		
		$( ".datepicker" ).datepicker();
		
		
		$('#datetimepicker1').datetimepicker({
			datepicker:false,
			format:'H:i',
			step:5
		});
		
		
		$("a.cancel_btn").click(function(){
			$("div.popup").fadeIn(300);
			return false
		});
		$("div.popup > a.close_btn").click(function(){
			$("div.popup").fadeOut(300);
			return false
		});
		
		
		$(".tab_content").hide(); //Hide all content
		$("ul.tabs li:first").addClass("active").show(); //Activate first tab
		$(".tab_content:first").show(); //Show first tab content
		//On Click Event
		$("ul.tabs li").click(function() {
			$("ul.tabs li").removeClass("active"); //Remove any "active" class
			$(this).addClass("active"); //Add "active" class to selected tab
			$(".tab_content").hide(); //Hide all tab content
			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active content
			return false;
		});
		
		
		
		$("a.open").click(function(){
			$("div.small_popup").fadeIn(300);
			$("body").append('<div class="mask"></div>');
			return false
		});
		$("div.small_popup > a.close_btn").click(function(){
			$("div.small_popup, div.mask").fadeOut(300, function() {
				$("div.mask").remove();
				
			});
			return false
		});
		
		
		$("a.open2").click(function(){
			$("div.big_popup").fadeIn(300);
			$("body").append('<div class="mask"></div>');
			$('.scroll-pane').jScrollPane();
			$('select.styled').customSelect();
			return false
		});
		$("div.big_popup > a.close_btn").click(function(){
			$("div.big_popup, div.mask").fadeOut(300, function() {
				$("div.mask").remove();
				
			});
			return false
		});
		
		
		
//		
//		$(".tab_content2").hide(); //Hide all content
//		$("ul.tabs2 li:first").addClass("active").show(); //Activate first tab
//		$(".tab_content2:first").show(); //Show first tab content
//		//On Click Event
//		$("ul.tabs2 li").click(function() {
//			$("ul.tabs2 li").removeClass("active"); //Remove any "active" class
//			$(this).addClass("active"); //Add "active" class to selected tab
//			$(".tab_content2").hide(); //Hide all tab content
//			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
//			$(activeTab).fadeIn(); //Fade in the active content
//			return false;
//		});
		
		
		
		
		
		
		
		$("a.open3").click(function(){
			$("div.slide_popup").fadeIn(300);
			return false
		});
		$("div.slide_popup > a.close_btn").click(function(){
			$("div.slide_popup").fadeOut(300);	
		return false
		});
		
		
		
	
		$(".tab_content3").hide(); //Hide all content
		$("ul.tabs3 li:first").addClass("active").show(); //Activate first tab
		$(".tab_content3:first").show(); //Show first tab content
		//On Click Event
		$("ul.tabs3 li").click(function() {
		$("ul.tabs3 li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content3").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active content
		return false;
		});	
		
		
		
		
		
		
		
	});
})(jQuery);