<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" media="all" href="css/jui.checkboxes.css">
</head>

<body>
<div class="details-n-winn-wrapper">
<figure class="imgedit"><img id="images1" src="img/top-img.jpg" alt=""></figure>

<h2 class="textedit">Fill in your details and win! </h2>
<div class="form-container jui-checkboxes-container" id="checkboxesInit2">
<form action="">
<ul>
	<li><label for="">EmaiL address</label><input name="" type="text"></li>
	<li><label for="">What kind of campaign are you Looking for? </label>
    <div class="jui-checkbox-row"> <span class="jui-checkbox" tabindex="0"></span>
    <label>option</label>
  </div>
  <div class="jui-checkbox-row"> <span class="jui-checkbox" tabindex="0"></span>
    <label>option</label>
  </div>
  <div class="jui-checkbox-row"> <span class="jui-checkbox" tabindex="0"></span>
    <label>option</label>
  </div>
    </li>
	<li><label for="">Your message</label><textarea name="" cols="" rows=""></textarea> </li>
	<li><input name="" type="submit" value="Send"></li>
</ul>
</form>
</div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="js/jquery.jui.checkboxes.js"></script> 
<script type="text/javascript">
           $("#checkboxesInit2").juicheckboxes();
        </script>
</body>

</html>
