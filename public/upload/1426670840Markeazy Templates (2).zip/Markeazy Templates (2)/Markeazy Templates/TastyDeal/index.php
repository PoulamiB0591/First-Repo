<!--SFPPAGE-->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <meta name="viewport" content="initial-scale=1, width=device-width, maximum-scale=1, minimum-scale=1, user-scalable=no">
        <link href='https://fonts.googleapis.com/css?family=Sigmar+One' rel='stylesheet' type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
                 <!--SFPScript   type="text/javascript" src="SFPURLLINK/js/jquery-1.9.1.min.js"></script>
                <!--SFPScript  type="text/javascript" src="SFPURLLINK/js/bootstrap.min.js"></script>
                <link rel="stylesheet" href="SFPURLLINK/css/bootstrap.min.css">
                <link rel="stylesheet" href="SFPURLLINK/css/style.css">
            </head>
            <body>
                <div id="wrapper">
                    <div ID="content-wrapper"><!-- START OF SECTION -->
                    <div data-lead-id="top-row" id="top-row" class="text-center">
                    <div
                    <div class="SFPTWO_TEXTEDIT">
                        <h1 data-lead-id="top-row-text" class="textedit SFPTWO_TAGEDIT edit explicit_edit">GRILLED TO PERFECTION - GET IT TODAY!</h1>
                        </div>
                       
                        <a href="#" data-lead-id="logo" ID="logo" class="SFPTWO_IMAGEEDIT">
                            <img src="img/logo.png" class="img-responsive center-block" />
                        </a>
                    </div>
                    <div class="hero-img-section text-center">
                    <div class="SFPTWO_IMAGEEDIT">
                        <img src="img/hero-image.jpg" data-lead-id="hero-img" class="img-responsive center-block" />
                        </div>
                        <div class="sunburst">
                        <div class="SFPTWO_IMAGEEDIT">
                            <img src="img/burst.png" data-lead-id="hero-burst" class="img-responsive center-block" />
                           </div>
                           <div class="SFPTWO_TEXTEDIT">
                         <div data-lead-id="burst-text" class="burst-text textedit SFPTWO_TAGEDIT edit explicit_edit"><span>$</span>6</div>
                      </div>
                        </div>
                    </div>
                    <div data-lead-id="details-section" ID="details-section"><!-- START OF SECTION -->
                    <div class="container-fluid">
                        <div data-lead-id="hero-text-container" class="row hero-text-container text-center">
                            <div class="col-md-12 SFPTWO_TEXTEDIT">
                                <span data-lead-id="hero-text" class="hero-text textedit SFPTWO_TAGEDIT edit explicit_edit">Limited Time Offer</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div data-lead-id="coupon-container" class="coupon-container">
                                <div class="SFPTWO_IMAGEEDIT">
                                    <img src="img/coupon-bg.jpg" data-lead-id="coupon-bg" class="coupon-bg" />
                                 </div>
                                    <div class="coupon-inner">
                                    <div class="SFPTWO_TEXTEDIT">
                                        <h2 data-lead-id="coupon-text1" class="textedit SFPTWO_TAGEDIT edit explicit_edit"><strong>BUY 1 & GET 1 FREE</strong></h2>
                                        </div>
                                        <div class="SFPTWO_TEXTEDIT">
                                        <a href="#" data-lead-id="coupon-btn" class="coupon-btn textedit SFPTWO_TAGEDIT edit explicit_edit">
                                            DOWNLOAD YOUR COUPON
                                        </a>
                                        </div>
                                        <div>
                                        <p data-lead-id="coupon-text2" class="SFPTWO_TEXTEDIT"><strong class="textedit SFPTWO_TAGEDIT edit explicit_edit">Offer Valid Until 12-15-2015</strong></p>
                                   </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="right-info-box text-center">
                                <div>
                                    <h3 data-lead-id="right-text1" class="SFPTWO_TEXTEDIT"><strong class="textedit SFPTWO_TAGEDIT edit explicit_edit>CALL NOW & ORDER</strong></h3>
                                   </div>
                                   <div>
                                    <h1 data-lead-id="right-text2" class="SFPTWO_TEXTEDIT"><strong class="textedit SFPTWO_TAGEDIT edit explicit_edit">123.456.2654</strong></h1>
                                  </div>
                                  <div>
                                    <h3 data-lead-id="right-text3" class="SFPTWO_TEXTEDIT"><strong>ORDER ONLINE:<BR />WWW.COOLBURGER.COM</strong></H3>
                               </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div><!-- END OF SECTION -->
                    <div data-lead-id="footer-section" ID="footer-section"><!-- START OF SECTION -->
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div data-lead-id="add-this" class="SFPTWO_IMAGEEDIT addthis_sharing_toolbox social-links">
                                    <img src="img/social_btns.png" />
                                </div>
                                <div>
                                <h1 data-lead-id="footer-text1" class="SFPTWO_TEXTEDIT"><strong class="textedit SFPTWO_TAGEDIT edit explicit_edit">- 123 MAIN STREET, PHOENIX ARIZON 85698 -</strong></h1>
                               </div>
                            <div class="SFPTWO_TEXTEDIT">
                                <p data-lead-id="legal-text" class="textedit SFPTWO_TAGEDIT edit explicit_edit">©2015 markeazy.com - Recommended image sizes in pixels (WxH) - Main Background: 1900x900 | Logo: 160x35 | Hero Image: 941x448 | Coupon Background: 415x204 - Please visit our <a href="http://markeazy.com/add-this-tutorial/">"Add This" tutorial page</a> to learn to use the social like and share buttons. To learn more about how you can increase your landing page conversions, or get more marketing goodies like this, then please visit <a href="http://markeazy.com">Markeazy.com</a> and if you have any questions please contact me (Travis) <a href="http://markeazy.com/contact/">here</a>. Thank you!</p>
                            </div>
                            </div>
                        </div>
                    </div>
                    </div><!-- END OF SECTION -->
                    
                    </div><!-- END OF CONTENT WRAPPER -->
                </div>
            </body>
        </html>